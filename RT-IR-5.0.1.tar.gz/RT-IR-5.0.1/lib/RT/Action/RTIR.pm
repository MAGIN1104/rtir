# BEGIN BPS TAGGED BLOCK {{{
#
# COPYRIGHT:
#
# This software is Copyright (c) 1996-2021 Best Practical Solutions, LLC
#                                          <sales@bestpractical.com>
#
# (Except where explicitly superseded by other copyright notices)
#
#
# LICENSE:
#
# This work is made available to you under the terms of Version 2 of
# the GNU General Public License. A copy of that license should have
# been provided with this software, but in any event can be snarfed
# from www.gnu.org.
#
# This work is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301 or visit their web page on the internet at
# http://www.gnu.org/licenses/old-licenses/gpl-2.0.html.
#
#
# CONTRIBUTION SUBMISSION POLICY:
#
# (The following paragraph is not intended to limit the rights granted
# to you to modify and distribute this software under the terms of
# the GNU General Public License and is only of importance to you if
# you choose to contribute your changes and enhancements to the
# community by submitting them to Best Practical Solutions, LLC.)
#
# By intentionally submitting any modifications, corrections or
# derivatives to this work, or any other work intended for use with
# Request Tracker, to Best Practical Solutions, LLC, you confirm that
# you are the copyright holder for those contributions and you grant
# Best Practical Solutions,  LLC a nonexclusive, worldwide, irrevocable,
# royalty-free, perpetual, license to use, copy, create derivative
# works based on those contributions, and sublicense and distribute
# those contributions and any derivatives thereof.
#
# END BPS TAGGED BLOCK }}}

use strict;
use warnings;

package RT::Action::RTIR;
use base 'RT::Action';

=head2 Prepare

RTIR's actions don't do anything by default.

=cut

sub Prepare { return 1 }

use RT::IR;

sub CreatorCurrentUser {
    my $self = shift;
    my $user = RT::CurrentUser->new($self->TransactionObj->CurrentUser);
    $user->Load($self->TransactionObj->Creator);
    return $user;
}

sub CopyCustomFields {
    my ($self, %args) = @_;

    for my $ticket (qw/From To/) {
        unless ( ref $args{$ticket} eq 'RT::Ticket' && $args{$ticket}->Id ) {
            RT->Logger->error("Argument $ticket isn't a ticket");
            return;
        }
    }

    unless ( defined $args{CF} ) {
        RT->Logger->error("Must pass a CF");
        return;
    }

    my $target = $args{To};
    my $source = $args{From};

    my $cf_name = $args{CF};

    my $target_cf = $target->LoadCustomFieldByIdentifier( $cf_name );
    unless ( $target_cf->Id ) {
        RT->Logger->error("Couldn't load CF $cf_name on ticket ".$target->Id);
        return;
    }
    my $has_values = $target->CustomFieldValues( $target_cf );

    my $source_cf = $source->LoadCustomFieldByIdentifier( $cf_name );
    unless ( $source_cf->Id ) {
        RT->Logger->error("Couldn't load CF $cf_name on ticket ".$source->Id);
        return;
    }
    my $add_values = $source->CustomFieldValues( $cf_name );

    while ( my $value = $add_values->Next ) {
        my $content = $value->Content;
        next if $has_values->HasEntry( $content );

        my ($status, $msg) = $target->AddCustomFieldValue(
            Value => $content,
            Field => $target_cf,
        );
        RT->Logger->error("Couldn't add $cf_name: $msg")
            unless $status;
    }

    return 1;

}

RT::IR->ImportOverlays;

1;
