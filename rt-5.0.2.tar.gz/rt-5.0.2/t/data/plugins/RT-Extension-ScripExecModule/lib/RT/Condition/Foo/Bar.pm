package RT::Condition::Foo::Bar;

use strict;
use warnings;
use base 'RT::Condition';

sub IsApplicable { return 1 }

1;
